Add a New Vertex to the Graph:

void Graph::add_vertex(char vertex_name) {
    if (adjList.find(vertex_name) == adjList.end()) {
        adjList[vertex_name] = {};
        cout << "Vertex " << vertex_name << " added.\n";
    } else {
        cout << "Vertex " << vertex_name << " already exists.\n";
    }
}


Output:
g.add_vertex('A');
g.add_vertex('B');




Add a New Edge Between Two Vertices:

void Graph::add_edge(char source, char destination, int weight) {
    adjList[source].emplace_back(destination, weight);
    adjList[destination].emplace_back(source, weight);
}

Input: g.add_edge('A', 'B', 50);
output: none (edge is added to the graphs internal structure)



Shortest Path Algo:

map<char, vector<pair<char, int>>> min_span_tree() const {
        if (is_empty()) {
            cout << "Error: Graph is empty. MST cannot be created." << endl;
            return {};
        }

        set<char> in_mst;
        map<char, vector<pair<char, int>>> mst;
        auto comp = [](const pair<int, pair<char, char>>& left, const pair<int, pair<char, char>>& right) { return left.first > right.first; };
        priority_queue<pair<int, pair<char, char>>, vector<pair<int, pair<char, char>>>, decltype(comp)> edges(comp);

        char start = adjList.begin()->first;
        in_mst.insert(start);
        for (const auto& edge : adjList.at(start)) {
            edges.emplace(edge.second, make_pair(start, edge.first));
        }

        while (!edges.empty()) {
            auto [weight, vertices] = edges.top();
            edges.pop();
            char from = vertices.first;
            char to = vertices.second;

            if (in_mst.insert(to).second) {
                mst[from].emplace_back(to, weight);
                for (const auto& edge : adjList.at(to)) {
                    if (in_mst.find(edge.first) == in_mst.end()) {
                        edges.emplace(edge.second, make_pair(to, edge.first));
                    }
                }
            }
        }

        if (mst.size() != adjList.size()) {
            cout << "The graph is disconnected. MST cannot be created for the entire graph." << endl;
            return {};
        }

        // Print MST and calculate total weight
        cout << "Minimum Spanning Tree (MST):" << endl;
        int totalWeight = 0;
        for (const auto& [from, edges] : mst) {
            for (const auto& [to, weight] : edges) {
                cout << from << " - " << to << " : " << weight << endl;
                totalWeight += weight;
            }
        }
        cout << "Total weight (miles) of the MST: " << totalWeight << endl;
        return mst;
    }
};



Input: No direct input min_span_tree() method in terms of arguments. Instead, it operates on the existing state of the graph, specifically the adjList, which is the adjacency list representing my graph.

Output:
The graph is disconnected. MST cannot be created for the entire graph.

If it were functional like one of my linkers:
A - B : 50
B - C : 40
(Further output showing the MST structure if connected)



